# Land-Registration-using-blockchain
Blockchain based land registration System made using flutter,solidity,truffle and ganache
