String mapBoxApiKey =
    'pk.eyJ1Ijoic2F1cmFiaG13IiwiYSI6ImNreTRiYzNidjBhMTkydnB2dmpoeGt4ZmgifQ.2QZ4CsNiygDTAhkqASpbPg';

String nftStorageApiKey =
    'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJkaWQ6ZXRocjoweDY4NDA3NmU2QzQ5YzZjYTUzMmMwYmVmQjFiYzJFNTA1OWYzMzU4MEYiLCJpc3MiOiJuZnQtc3RvcmFnZSIsImlhdCI6MTY4NjQxMzUzNTU0MSwibmFtZSI6ImxhbmRfcmVnaXN0cnkifQ.wKNFJOvSZSKWB4xc4yw7jhAJK4uNsQpyv3rrugWiszA';

const String rpcUrl = "http://127.0.0.1:7545";

const String contractAddress = "0x62F85E814C97eb9c6d2E03F9d1b1a7077FEA2078";

const int chainId = 1337; // local ganache-1337
